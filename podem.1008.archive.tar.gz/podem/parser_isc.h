#ifndef PARSER_ISC_H
#define PARSER_ISC_H

CIRCUIT* parse_isc_main(string filename);

#endif // PARSER_ISC_H